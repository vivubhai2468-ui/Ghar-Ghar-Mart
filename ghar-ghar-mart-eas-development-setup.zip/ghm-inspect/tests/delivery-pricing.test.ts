import { describe, expect, it } from "vitest";
import { calculateDeliveryCharge } from "../shared/delivery-pricing";

describe("delivery pricing", () => {
  it.each([[0.5, 10], [2, 10], [2.1, 15], [2.9, 15], [3, 15], [3.1, 20], [4.2, 25], [5, 25], [6, 30], [10, 50]])("charges %s km at ₹%s", (distance, charge) => {
    expect(calculateDeliveryCharge(distance).deliveryCharge).toBe(charge);
  });
  it("rejects invalid distance", () => expect(() => calculateDeliveryCharge(-1)).toThrow());
});
