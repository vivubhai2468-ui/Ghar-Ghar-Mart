import { describe, expect, it } from "vitest";

import { getRegistrationFieldErrors } from "../lib/registration-validation";

describe("registration field validation", () => {
  it("allows a complete direct customer registration", () => {
    expect(getRegistrationFieldErrors({
      name: "Vivekanand Kumar",
      phone: "9631143837",
      address: "House 18, Main Road, Patna",
      password: "securepass1",
      role: "customer",
      aadhaarNumber: "",
    })).toEqual({});
  });

  it("returns field-specific messages instead of a generic validation failure", () => {
    expect(getRegistrationFieldErrors({
      name: "V",
      phone: "9631",
      address: "",
      password: "short",
      role: "customer",
      aadhaarNumber: "",
    })).toMatchObject({
      name: expect.stringContaining("full name"),
      phone: expect.stringContaining("10-digit"),
      address: expect.stringContaining("house"),
      password: expect.stringContaining("8 characters"),
    });
  });

  it("requires Aadhaar only when registering as a seller", () => {
    expect(getRegistrationFieldErrors({
      name: "Seller Kumar",
      phone: "9631143837",
      address: "House 18, Main Road, Patna",
      password: "",
      role: "seller",
      aadhaarNumber: "123",
    }).aadhaarNumber).toContain("12-digit");
  });
});
