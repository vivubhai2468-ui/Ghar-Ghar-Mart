import { describe, expect, it } from "vitest";
import { appRouter } from "../server/routers";
import { createPhoneOtpChallenge, getUserById, getUserByPhone } from "../server/db";

function uniquePhone(seed: number) {
  return `7${String(seed).slice(-9)}`;
}

function callerFor(user: any) {
  return appRouter.createCaller({
    user,
    req: {} as any,
    res: { cookie: () => undefined, clearCookie: () => undefined } as any,
  });
}

function publicCaller() {
  return appRouter.createCaller({
    user: null,
    req: {} as any,
    res: { cookie: () => undefined, clearCookie: () => undefined } as any,
  });
}

async function signUpAndSignIn(input: {
  phone: string;
  name: string;
  role: "seller" | "delivery_partner";
  address?: string;
  shopName?: string;
  aadhaarNumber: string;
}) {
  const caller = publicCaller();
  const signupChallenge = await createPhoneOtpChallenge(input.phone, "signup");
  const signup = await caller.auth.phoneOtp.signUp({
    ...input,
    address: input.address ?? "15 Market Road, Mumbai",
    code: signupChallenge.code,
  });

  const loginChallenge = await createPhoneOtpChallenge(input.phone, "login");
  const login = await caller.auth.phoneOtp.signIn({ phone: input.phone, code: loginChallenge.code });
  return { signup, login };
}

describe("partner OTP authentication", () => {
  it("creates a pending seller account and routes subsequent OTP login as seller", async () => {
    const phone = uniquePhone(Date.now());
    const { signup, login } = await signUpAndSignIn({
      phone,
      name: "Auth Seller",
      role: "seller",
      shopName: "Auth Fresh Mart",
      aadhaarNumber: "123456789012",
    });

    expect(signup.user).toMatchObject({ role: "seller", sellerStatus: "pending" });
    expect(login.user).toMatchObject({ role: "seller" });
    expect((await getUserByPhone(phone))?.shopStatus).toBe("pending");
  }, 15_000);

  it("creates a pending delivery account, routes OTP login, and receives an approval notification", async () => {
    const phone = uniquePhone(Date.now() + 1);
    const { signup, login } = await signUpAndSignIn({
      phone,
      name: "Auth Delivery Partner",
      role: "delivery_partner",
      aadhaarNumber: "987654321098",
    });

    expect(signup.user).toMatchObject({ role: "delivery_partner", deliveryPartnerStatus: "pending" });
    expect(login.user).toMatchObject({ role: "delivery_partner", deliveryPartnerStatus: "pending" });
    const pendingPartner = await getUserByPhone(phone);
    expect(pendingPartner?.deliveryPartnerStatus).toBe("pending");

    const adminCaller = callerFor({ ...pendingPartner, role: "admin", name: "Approval Admin" });
    await adminCaller.admin.deliveryPartnerReviews.review({ partnerId: Number(pendingPartner?.id), status: "approved" });
    const partnerCaller = callerFor(await getUserById(Number(pendingPartner?.id)));
    const approvalNotification = (await partnerCaller.notifications.list()).find((notification: any) => notification.type === "delivery_partner_review");
    expect(approvalNotification).toMatchObject({
      userId: pendingPartner?.id,
      title: "Delivery profile approved",
      isRead: false,
    });
  }, 15_000);
});
