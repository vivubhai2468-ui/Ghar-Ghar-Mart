import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as Location from 'expo-location';
import { useAuth, type UserRole } from '@/lib/auth-context';
import { shouldRequestForegroundLocationAfterLogin } from '@/lib/delivery-location-permission';
import { useColors } from '@/hooks/use-colors';
import { ScreenContainer } from '@/components/screen-container';
import { trpc } from '@/lib/trpc';
import { getSignedInEntryRoute } from '@/lib/entry-routing';
import { getUserFacingError } from '@/lib/user-facing-error';

export default function LoginScreen() {
  const [phone, setPhone] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('customer');
  const [showOTP, setShowOTP] = useState(false);
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { completeVerifiedPhoneAuth, loginAsGuest } = useAuth();
  const colors = useColors();
  const requestOtp = trpc.auth.phoneOtp.request.useMutation();
  const verifyOtp = trpc.auth.phoneOtp.signIn.useMutation();
  const directCustomerSignIn = trpc.auth.directCustomer.signIn.useMutation();

  const requestDeliveryPartnerLocationPermission = async () => {
    if (Platform.OS === 'web') return;
    try {
      if (!await Location.hasServicesEnabledAsync()) {
        Alert.alert('Turn on location services', 'Enable device location so delivery progress can be shared once you start a route.');
        return;
      }
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Location access needed', 'Enable location access in device settings to share live delivery progress after a route starts.');
      }
    } catch {
      Alert.alert('Location setup unavailable', 'You can enable location access later in device settings before starting a delivery route.');
    }
  };

  const handleDirectCustomerSignIn = async () => {
    if (phone.replace(/\D/g, '').length !== 10) {
      Alert.alert('Check your mobile number', 'Enter a valid 10-digit mobile number.');
      return;
    }
    if (password.length < 8) {
      Alert.alert('Check your password', 'Your password must contain at least 8 characters.');
      return;
    }
    try {
      const result = await directCustomerSignIn.mutateAsync({ phone, password });
      await completeVerifiedPhoneAuth(result);
      router.replace(getSignedInEntryRoute('customer'));
    } catch (error) {
      Alert.alert('Could not sign in', getUserFacingError(error, 'Please check your mobile number and password.'));
    }
  };

  const handleSendOTP = async () => {
    if (!phone || phone.length < 10) {
      Alert.alert('Error', 'Please enter a valid phone number');
      return;
    }
    setIsLoading(true);
    try {
      const result = await requestOtp.mutateAsync({ phone, purpose: 'login' });
      setShowOTP(true);
      if (result.previewCode) {
        Alert.alert('Preview OTP', `Use ${result.previewCode} while SMS delivery is not configured.`);
      }
    } catch (error) {
      Alert.alert('Unable to send code', getUserFacingError(error, 'Please try again in a moment.'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!/^\d{6}$/.test(otp)) {
      Alert.alert('Error', 'Please enter the 6-digit OTP');
      return;
    }
    setIsLoading(true);
    try {
      const result = await verifyOtp.mutateAsync({ phone, code: otp });
      const isSellerAccount = result.user.role === 'seller';
      const isDeliveryPartnerAccount = result.user.role === 'delivery_partner';
      if (selectedRole === 'seller' && !isSellerAccount) {
        Alert.alert(
          'Seller account not found',
          'This mobile number is registered as a customer. Create or upgrade it as a seller to open the Seller Panel.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Create seller account', onPress: () => router.replace('/register') },
          ],
        );
        return;
      }
      if (selectedRole === 'delivery_partner' && !isDeliveryPartnerAccount) {
        Alert.alert('Delivery partner account not found', 'This mobile number is not assigned as a delivery partner. Ask operations to create your delivery account.');
        return;
      }
      await completeVerifiedPhoneAuth(result);
      const signedInRole = isSellerAccount ? 'seller' : isDeliveryPartnerAccount ? 'delivery_partner' : 'customer';
      if (shouldRequestForegroundLocationAfterLogin(signedInRole, result.user.deliveryPartnerStatus)) {
        await requestDeliveryPartnerLocationPermission();
      }
      router.replace(getSignedInEntryRoute(signedInRole));
    } catch (error) {
      Alert.alert('Verification failed', getUserFacingError(error, 'The code could not be verified. Please try again.'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestMode = async () => {
    await loginAsGuest();
    router.replace('/(tabs)');
  };

  const roles: Array<{ label: string; value: UserRole }> = [
    { label: 'Customer', value: 'customer' },
    { label: 'Seller', value: 'seller' },
    { label: 'Delivery Partner', value: 'delivery_partner' },
  ];

  return (
    <ScreenContainer className="bg-background" containerClassName="bg-background">
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            Welcome to Ghar Ghar Mart
          </Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>
            Sign in to your account
          </Text>
        </View>

        {/* Role Selection */}
        <View style={styles.roleContainer}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            Login as:
          </Text>
          <View style={styles.roleButtons}>
            {roles.map((role) => (
              <TouchableOpacity
                key={role.value}
                onPress={() => setSelectedRole(role.value)}
                style={[
                  styles.roleButton,
                  {
                    backgroundColor:
                      selectedRole === role.value
                        ? colors.primary
                        : colors.surface,
                    borderColor: colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.roleButtonText,
                    {
                      color:
                        selectedRole === role.value
                          ? colors.background
                          : colors.foreground,
                    },
                  ]}
                >
                  {role.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {selectedRole === 'customer' ? (
          <>
            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.foreground }]}> 
                Phone Number
              </Text>
              <View
                style={[
                  styles.inputWrapper,
                  { borderColor: colors.border, backgroundColor: colors.surface },
                ]}
              >
                <Text style={[styles.countryCode, { color: colors.muted }]}>
                  +91
                </Text>
                <TextInput
                  style={[styles.input, { color: colors.foreground }]}
                  placeholder="Enter your phone number"
                  placeholderTextColor={colors.muted}
                  keyboardType="phone-pad"
                  value={phone}
                  onChangeText={setPhone}
                  editable={!isLoading}
                />
              </View>
            </View>
            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.foreground }]}>Password</Text>
              <TextInput
                style={[styles.passwordInput, { borderColor: colors.border, backgroundColor: colors.surface, color: colors.foreground }]}
                placeholder="Enter your password"
                placeholderTextColor={colors.muted}
                secureTextEntry
                value={password}
                onChangeText={setPassword}
                editable={!directCustomerSignIn.isPending}
                autoComplete="password"
              />
            </View>

            <TouchableOpacity
              onPress={handleDirectCustomerSignIn}
              disabled={directCustomerSignIn.isPending}
              style={[
                styles.primaryButton,
                { backgroundColor: colors.primary, opacity: directCustomerSignIn.isPending ? 0.6 : 1 },
              ]}
            >
              {directCustomerSignIn.isPending ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <Text style={[styles.primaryButtonText, { color: colors.background }]}> 
                  Sign in
                </Text>
              )}
            </TouchableOpacity>
          </>
        ) : !showOTP ? (
          <>
            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.foreground }]}>Phone Number</Text>
              <View style={[styles.inputWrapper, { borderColor: colors.border, backgroundColor: colors.surface }]}>
                <Text style={[styles.countryCode, { color: colors.muted }]}>+91</Text>
                <TextInput style={[styles.input, { color: colors.foreground }]} placeholder="Enter your phone number" placeholderTextColor={colors.muted} keyboardType="phone-pad" value={phone} onChangeText={setPhone} editable={!isLoading} />
              </View>
            </View>
            <TouchableOpacity onPress={handleSendOTP} disabled={isLoading} style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: isLoading ? 0.6 : 1 }]}>
              {isLoading ? <ActivityIndicator color={colors.background} /> : <Text style={[styles.primaryButtonText, { color: colors.background }]}>Send verification code</Text>}
            </TouchableOpacity>
          </>
        ) : (
          <>
            {/* OTP Input */}
            <View style={styles.inputContainer}>
              <Text style={[styles.label, { color: colors.foreground }]}>
                Enter OTP
              </Text>
              <Text style={[styles.otpInfo, { color: colors.muted }]}> 
                We&apos;ve sent a 6-digit code to {phone}
              </Text>
              <TextInput
                style={[
                  styles.otpInput,
                  { borderColor: colors.primary, color: colors.foreground },
                ]}
                placeholder="000000"
                placeholderTextColor={colors.muted}
                keyboardType="number-pad"
                maxLength={6}
                value={otp}
                onChangeText={setOtp}
                editable={!isLoading}
                textContentType="oneTimeCode"
                autoComplete="sms-otp"
              />
            </View>

            {/* Verify OTP Button */}
            <TouchableOpacity
              onPress={handleVerifyOTP}
              disabled={isLoading}
              style={[
                styles.primaryButton,
                { backgroundColor: colors.primary, opacity: isLoading ? 0.6 : 1 },
              ]}
            >
              {isLoading ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <Text style={[styles.primaryButtonText, { color: colors.background }]}>
                  Verify OTP
                </Text>
              )}
            </TouchableOpacity>

            {/* Change Phone */}
            <TouchableOpacity onPress={() => setShowOTP(false)}>
              <Text style={[styles.changePhoneText, { color: colors.primary }]}>
                Change phone number
              </Text>
            </TouchableOpacity>
          </>
        )}

        {/* Guest Mode */}
        <TouchableOpacity
          onPress={handleGuestMode}
          style={[styles.secondaryButton, { borderColor: colors.primary }]}
        >
          <Text style={[styles.secondaryButtonText, { color: colors.primary }]}>
            Continue as Guest
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => router.push('/register')} style={{ alignSelf: 'center', marginTop: 18 }}>
          <Text style={{ color: colors.primary, fontWeight: '700', fontSize: 14 }}>New customer? Create your account</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push('/register')} style={{ alignSelf: 'center', marginTop: 14 }}>
          <Text style={{ color: colors.primary, fontWeight: '700', fontSize: 14 }}>Want to sell with us? Create a verified seller account</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push('/delivery-register')} style={{ alignSelf: 'center', marginTop: 14, marginBottom: 8 }}>
          <Text style={{ color: colors.primary, fontWeight: '700', fontSize: 14 }}>Want to deliver with us? Create a delivery partner account</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  header: {
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
  },
  roleContainer: {
    marginBottom: 30,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  roleButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  roleButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  roleButtonText: {
    fontSize: 12,
    fontWeight: '600',
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 50,
  },
  countryCode: {
    fontSize: 16,
    fontWeight: '600',
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
  },
  passwordInput: {
    height: 50,
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    fontSize: 16,
  },
  otpInfo: {
    fontSize: 12,
    marginBottom: 12,
  },
  otpInput: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    borderWidth: 2,
    borderRadius: 12,
    paddingVertical: 12,
    letterSpacing: 10,
  },
  primaryButton: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  secondaryButton: {
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  secondaryButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  changePhoneText: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 16,
  },
});
